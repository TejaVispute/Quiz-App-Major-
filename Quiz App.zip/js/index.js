printname = () =>{
        const val = document.querySelector('input-val').value;
        
}